import { Link, useLocation } from "@tanstack/react-router";
import { useTranslation } from "react-i18next";
import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { getLocaleFromPath, localizedPath } from "@/lib/locale";
import { LanguageSwitcher } from "./LanguageSwitcher";
import { cn } from "@/lib/utils";

export function Navbar() {
  const { t } = useTranslation();
  const { pathname } = useLocation();
  const locale = getLocaleFromPath(pathname);
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const home = localizedPath(locale, "/");
  const menu = localizedPath(locale, "/menu");

  const links = [
    { href: home, label: t("nav.home") },
    { href: `${home === "/" ? "" : home}#about`, label: t("nav.about") },
    { href: `${home === "/" ? "" : home}#dishes`, label: t("nav.dishes") },
    { href: menu, label: t("nav.menu") },
    { href: `${home === "/" ? "" : home}#contact`, label: t("nav.contact") },
  ];

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled || open
          ? "bg-cream/95 backdrop-blur-md shadow-sm border-b border-border/60"
          : "bg-transparent",
      )}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 md:px-8">
        <Link
          to={home}
          className="font-serif text-2xl tracking-tight text-foreground hover:text-primary transition-colors"
          onClick={() => setOpen(false)}
        >
          Restaurante <span className="text-primary italic">Lino</span>
        </Link>

        <nav className="hidden items-center gap-8 lg:flex">
          {links.map((l) => (
            <a
              key={l.href + l.label}
              href={l.href}
              className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors"
            >
              {l.label}
            </a>
          ))}
          <LanguageSwitcher />
          <a
            href={menu}
            className="inline-flex items-center rounded-full bg-primary px-5 py-2 text-sm font-medium text-primary-foreground hover:bg-[oklch(0.36_0.13_25)] transition-colors"
          >
            {t("nav.reserve")}
          </a>
        </nav>

        <button
          aria-label="Toggle menu"
          className="lg:hidden p-2 text-foreground"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden border-t border-border/60 bg-cream/98 backdrop-blur-md">
          <nav className="flex flex-col px-6 py-4">
            {links.map((l) => (
              <a
                key={l.href + l.label}
                href={l.href}
                className="py-3 text-base font-medium text-foreground/85 hover:text-primary border-b border-border/40 last:border-0"
                onClick={() => setOpen(false)}
              >
                {l.label}
              </a>
            ))}
            <div className="pt-4">
              <LanguageSwitcher />
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}

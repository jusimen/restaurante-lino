import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { MenuPageContent } from "@/components/MenuPageContent";

export const Route = createFileRoute("/menu")({
  head: () => ({
    meta: [
      { title: "Ementa · Restaurante Lino" },
      {
        name: "description",
        content:
          "Consulte a ementa do Restaurante Lino: entradas, carnes, peixes, bacalhau, sobremesas caseiras e vinhos da região do Minho.",
      },
      { property: "og:title", content: "Ementa · Restaurante Lino" },
      { property: "og:description", content: "Pratos tradicionais minhotos, vinhos verdes e sobremesas de família." },
      { property: "og:url", content: "/menu" },
    ],
    links: [
      { rel: "canonical", href: "/menu" },
      { rel: "alternate", hrefLang: "pt-PT", href: "/menu" },
      { rel: "alternate", hrefLang: "en", href: "/en/menu" },
    ],
  }),
  component: MenuPage,
});

function MenuPage() {
  return (
    <>
      <Navbar />
      <main className="pt-24">
        <MenuPageContent />
      </main>
      <Footer />
    </>
  );
}
